﻿#region Using directives

using System;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security;
using System.Security.Permissions;

#endregion

[assembly: AssemblyTitle("BlogEngine.NET")]
[assembly: AssemblyDescription("BlogEngine.NET")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("BlogEngine.NET")]
[assembly: AssemblyCopyright("Copyright @ 2007-2019")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: CLSCompliant(false)]
[assembly: ComVisible(false)]
[assembly: AllowPartiallyTrustedCallers]
[assembly: AssemblyVersion("3.3.8.0")]
[assembly: SecurityRules(SecurityRuleSet.Level1)]